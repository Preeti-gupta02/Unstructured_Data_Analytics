# NOTE TO GRADER #

Please download the "car model brands.csv" file located along with the other zipped items.

In order to have interpretable outputs, we removed some "brands" such as "car" etc. that were not easily interpretable.